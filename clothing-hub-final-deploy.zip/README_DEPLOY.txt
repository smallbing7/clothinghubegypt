# Clothing Hub Egypt — FINAL DEPLOY PACKAGE

Upload the ENTIRE folder contents. Keep `images/` beside `index.html`.

Required structure:
index.html
style.css
script.js
favicon.svg
images/

Do not upload only index.html.

Images are referenced as `./images/...` so relative paths work on static hosting.

Real account login/OTP and affiliate database submission require Supabase credentials in script.js:
YOUR_SUPABASE_PROJECT_URL
YOUR_SUPABASE_ANON_KEY

Without Supabase, the public catalogue, product image lightbox and WhatsApp inquiry features can still work.
